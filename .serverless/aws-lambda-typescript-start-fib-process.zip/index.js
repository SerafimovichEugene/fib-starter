"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startFib = void 0;
const axios_1 = __importDefault(require("axios"));
const nanoid_1 = require("nanoid");
async function startFib(event) {
    const { queryStringParameters } = event;
    if (queryStringParameters === null) {
        return { statusCode: 401, body: 'miss path' };
    }
    const { n } = queryStringParameters;
    if (!n) {
        return { statusCode: 401, body: '' };
    }
    const jobId = nanoid_1.nanoid();
    const endpoint = 'http://54.93.81.82:3001/fib';
    try {
        const { data } = await axios_1.default.get(endpoint, {
            params: { n, jobId }
        });
        console.log('---- data ', data);
        return {
            statusCode: 200,
            body: JSON.stringify({ jobId })
        };
    }
    catch (err) {
        console.log(JSON.stringify(err, null, 2));
        return {
            statusCode: 500,
            body: JSON.stringify({ jobId, error: true })
        };
    }
}
exports.startFib = startFib;
